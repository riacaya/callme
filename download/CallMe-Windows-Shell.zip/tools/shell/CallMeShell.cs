using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace CallMeShell
{
    internal static class Program
    {
        internal const string AppUrl = "https://riacaya.github.io/callme/";
        internal const string AppName = "CallMe";
        internal const string StartupValueName = "CallMe";
        private static string _logFile;

        [STAThread]
        static void Main(string[] args)
        {
            bool created;
            using (var mutex = new Mutex(true, "Local\\CallMeShell-SingleInstance", out created))
            {
                if (!created)
                {
                    return;
                }

                string dataDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "CallMe");
                try { Directory.CreateDirectory(dataDir); } catch { }
                _logFile = Path.Combine(dataDir, "callme-shell.log");
                Log("CallMe Shell start " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                try
                {
                    Application.Run(new MainForm());
                }
                catch (Exception ex)
                {
                    Log("Fatal: " + ex.ToString());
                    MessageBox.Show("CallMe gagal dimulai:\n" + ex.Message, AppName,
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        internal static void Log(string s)
        {
            try
            {
                if (_logFile == null) return;
                try
                {
                    var fi = new FileInfo(_logFile);
                    if (fi.Exists && fi.Length > 1024 * 1024) fi.Delete();
                }
                catch { }
                File.AppendAllText(_logFile, DateTime.Now.ToString("HH:mm:ss") + "  " + s + "\r\n");
            }
            catch { }
        }

        internal static string AppDir
        {
            get
            {
                try { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? "."; }
                catch { return "."; }
            }
        }

        internal static string ExePath
        {
            get
            {
                try { return Assembly.GetExecutingAssembly().Location; }
                catch { return Application.ExecutablePath; }
            }
        }
    }

    internal class MainForm : Form
    {
        private WebView2 _web;
        private NotifyIcon _tray;
        private bool _allowExit;
        private ToolStripMenuItem _startupItem;
        private IncomingCallForm _incomingCallForm;

        internal MainForm()
        {
            Text = "CallMe";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1100, 760);
            MinimumSize = new Size(420, 560);
            AutoScaleMode = AutoScaleMode.Font;
            try { Icon = LoadAppIcon(); } catch { }

            SetupTray();
            Shown += async delegate(object s, EventArgs e) { await InitWebViewAsync(); };
            FormClosing += OnFormClosing;
            Resize += delegate(object s, EventArgs e) { if (WindowState == FormWindowState.Minimized) HideToTray(); };
        }

        private Icon LoadAppIcon()
        {
            string png = Path.Combine(Program.AppDir, "assets", "logo-192.png");
            if (File.Exists(png))
            {
                try
                {
                    using (var bmp = new Bitmap(png))
                    {
                        IntPtr h = bmp.GetHicon();
                        Icon ico = Icon.FromHandle(h);
                        return (Icon)ico.Clone();
                    }
                }
                catch { }
            }
            return SystemIcons.Application;
        }

        private void SetupTray()
        {
            var menu = new ContextMenuStrip();
            menu.Items.Add("Buka CallMe", null, delegate(object s, EventArgs e) { ShowFromTray(); });
            _startupItem = new ToolStripMenuItem("Mulai saat Windows menyala", null, delegate(object s, EventArgs e) { ToggleStartup(); });
            _startupItem.Checked = IsStartupEnabled();
            menu.Items.Add(_startupItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Keluar", null, delegate(object s, EventArgs e) { ExitApp(); });

            _tray = new NotifyIcon();
            _tray.Text = "CallMe";
            _tray.Icon = LoadAppIcon();
            _tray.Visible = true;
            _tray.ContextMenuStrip = menu;
            _tray.DoubleClick += delegate(object s, EventArgs e) { ShowFromTray(); };
            _tray.BalloonTipClicked += delegate(object s, EventArgs e) { ShowFromTray(); };
        }

        private async Task InitWebViewAsync()
        {
            try
            {
                string profile = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "CallMe", "WebView2");
                var env = await CoreWebView2Environment.CreateAsync(null, profile, null);
                _web = new WebView2();
                _web.Dock = DockStyle.Fill;
                Controls.Add(_web);
                _web.BringToFront();
                await _web.EnsureCoreWebView2Async(env);
                _web.CoreWebView2.Settings.IsStatusBarEnabled = false;
                _web.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
                _web.CoreWebView2.Settings.IsWebMessageEnabled = true;
                _web.CoreWebView2.WebMessageReceived += delegate(object s, CoreWebView2WebMessageReceivedEventArgs e)
                {
                    try { HandleWebMessage(e.TryGetWebMessageAsString()); } catch (Exception ex) { Program.Log("WebMessage error: " + ex.Message); }
                };
                _web.CoreWebView2.NewWindowRequested += delegate(object s, CoreWebView2NewWindowRequestedEventArgs e)
                {
                    var uri = e.Uri ?? "";
                    if (uri.StartsWith("http://") || uri.StartsWith("https://"))
                    {
                        if (!uri.StartsWith("https://riacaya.github.io/callme", StringComparison.OrdinalIgnoreCase))
                        {
                            e.Handled = true;
                            try { Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); } catch { }
                            return;
                        }
                    }
                    e.Handled = true;
                    if (!string.IsNullOrEmpty(uri)) _web.CoreWebView2.Navigate(uri);
                };
                _web.CoreWebView2.PermissionRequested += delegate(object s, CoreWebView2PermissionRequestedEventArgs e)
                {
                    if (e.PermissionKind == CoreWebView2PermissionKind.Microphone ||
                        e.PermissionKind == CoreWebView2PermissionKind.Camera ||
                        e.PermissionKind == CoreWebView2PermissionKind.Notifications)
                    {
                        var u = e.Uri ?? "";
                        if (u.StartsWith("https://riacaya.github.io/", StringComparison.OrdinalIgnoreCase))
                            e.State = CoreWebView2PermissionState.Allow;
                    }
                };
                _web.Source = new Uri(Program.AppUrl);
                Program.Log("WebView ready: " + Program.AppUrl);
            }
            catch (Exception ex)
            {
                Program.Log("WebView2 init failed: " + ex.Message);
                MessageBox.Show(this,
                    "Runtime Microsoft Edge WebView2 tidak tersedia.\n\nUnduh dan pasang:\nhttps://developer.microsoft.com/microsoft-edge/webview2/\n\nDetail: " + ex.Message,
                    Program.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Close();
            }
        }

        private void HandleWebMessage(string json)
        {
            if (string.IsNullOrEmpty(json)) return;
            string type = JsonField(json, "type");
            if (type == "incoming-call")
            {
                string title = JsonField(json, "title");
                string body = JsonField(json, "body");
                if (string.IsNullOrEmpty(title)) title = "Panggilan masuk";
                if (string.IsNullOrEmpty(body)) body = "Ada panggilan masuk";
                Program.Log("Incoming call: " + title + " | " + body);
                BeginInvoke(new Action(delegate { ShowIncomingCallUi(title, body); }));
                return;
            }
            if (type == "incoming-message")
            {
                string title = JsonField(json, "title");
                string body = JsonField(json, "body");
                if (string.IsNullOrEmpty(title)) title = "CallMe";
                if (string.IsNullOrEmpty(body)) body = "Pesan baru";
                Program.Log("Notify: message | " + title + " | " + body);
                try { _tray.ShowBalloonTip(4000, title, body, ToolTipIcon.Info); } catch { }
            }
        }

        private void ShowIncomingCallUi(string title, string body)
        {
            try
            {
                if (_incomingCallForm != null && !_incomingCallForm.IsDisposed)
                {
                    _incomingCallForm.UpdateInfo(title, body);
                    _incomingCallForm.Activate();
                    return;
                }
                _incomingCallForm = new IncomingCallForm(title, body,
                    delegate { OnCallAction("accept"); },
                    delegate { OnCallAction("reject"); });
                _incomingCallForm.FormClosed += delegate { _incomingCallForm = null; };
                _incomingCallForm.Show();
                _incomingCallForm.Activate();
            }
            catch (Exception ex) { Program.Log("IncomingCallUi error: " + ex.Message); }
        }

        private void OnCallAction(string action)
        {
            try
            {
                if (action == "accept") ShowFromTray();
                if (_web != null && _web.CoreWebView2 != null)
                {
                    string msg = "{\"type\":\"call-action\",\"action\":\"" + action + "\"}";
                    _web.CoreWebView2.PostWebMessageAsString(msg);
                }
            }
            catch (Exception ex) { Program.Log("Post call action failed: " + ex.Message); }
            try { if (_incomingCallForm != null && !_incomingCallForm.IsDisposed) _incomingCallForm.Close(); } catch { }
        }

        private static string JsonField(string json, string name)
        {
            try
            {
                var m = Regex.Match(json, "\"" + Regex.Escape(name) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
                if (!m.Success) return "";
                string v = m.Groups[1].Value;
                v = Regex.Replace(v, "\\\\u([0-9a-fA-F]{4})", delegate(Match mm) {
                    try { return ((char)Convert.ToInt32(mm.Groups[1].Value, 16)).ToString(); } catch { return mm.Value; }
                });
                v = v.Replace("\\\"", "\"").Replace("\\\\", "\\").Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\t", "\t");
                return v;
            }
            catch { return ""; }
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (_allowExit) return;
            e.Cancel = true;
            HideToTray();
            try { _tray.ShowBalloonTip(2500, "CallMe", "CallMe tetap berjalan di system tray untuk menerima notifikasi/panggilan.", ToolTipIcon.Info); } catch { }
        }

        private void HideToTray()
        {
            ShowInTaskbar = false;
            Hide();
        }

        private void ShowFromTray()
        {
            ShowInTaskbar = true;
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        private void ExitApp()
        {
            _allowExit = true;
            try { _tray.Visible = false; _tray.Dispose(); } catch { }
            try { if (_incomingCallForm != null && !_incomingCallForm.IsDisposed) _incomingCallForm.Close(); } catch { }
            try { if (_web != null) _web.Dispose(); } catch { }
            Application.Exit();
        }

        private static string RunKeyPath
        {
            get { return @"Software\Microsoft\Windows\CurrentVersion\Run"; }
        }

        private bool IsStartupEnabled()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, false))
                {
                    if (key == null) return false;
                    var val = key.GetValue(Program.StartupValueName) as string;
                    return !string.IsNullOrEmpty(val);
                }
            }
            catch { return false; }
        }

        private void ToggleStartup()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, true))
                {
                    if (key == null) return;
                    if (IsStartupEnabled())
                    {
                        key.DeleteValue(Program.StartupValueName, false);
                        if (_startupItem != null) _startupItem.Checked = false;
                        Program.Log("Startup disabled");
                    }
                    else
                    {
                        string cmd = "\"" + Program.ExePath + "\"";
                        key.SetValue(Program.StartupValueName, cmd);
                        if (_startupItem != null) _startupItem.Checked = true;
                        Program.Log("Startup enabled");
                    }
                }
            }
            catch (Exception ex)
            {
                Program.Log("Startup toggle failed: " + ex.Message);
                MessageBox.Show(this, "Gagal mengubah pengaturan startup:\n" + ex.Message, Program.AppName,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

    internal class IncomingCallForm : Form
    {
        private Label _titleLabel;
        private Label _bodyLabel;
        private Action _onAccept;
        private Action _onReject;

        internal IncomingCallForm(string title, string body, Action onAccept, Action onReject)
        {
            _onAccept = onAccept;
            _onReject = onReject;
            Text = "CallMe - Panggilan Masuk";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            TopMost = true;
            ShowInTaskbar = true;
            ClientSize = new Size(360, 170);

            _titleLabel = new Label { AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Top, Height = 40, Font = new Font(SystemFonts.DefaultFont.FontFamily, 12f, FontStyle.Bold), Text = title ?? "Panggilan masuk" };
            _bodyLabel = new Label { AutoSize = false, TextAlign = ContentAlignment.TopCenter, Dock = DockStyle.Top, Height = 50, Padding = new Padding(12, 4, 12, 4), Text = body ?? "" };

            var panel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 60, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(12) };
            var rejectBtn = new Button { Text = "Tolak", Width = 110, Height = 34, BackColor = Color.FromArgb(220, 53, 69), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            var acceptBtn = new Button { Text = "Terima", Width = 110, Height = 34, BackColor = Color.FromArgb(40, 167, 69), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            rejectBtn.FlatAppearance.BorderSize = 0;
            acceptBtn.FlatAppearance.BorderSize = 0;
            acceptBtn.Click += delegate { try { if (_onAccept != null) _onAccept(); } catch { } };
            rejectBtn.Click += delegate { try { if (_onReject != null) _onReject(); } catch { } };
            panel.Controls.Add(rejectBtn);
            panel.Controls.Add(acceptBtn);

            Controls.Add(panel);
            Controls.Add(_bodyLabel);
            Controls.Add(_titleLabel);
        }

        internal void UpdateInfo(string title, string body)
        {
            if (_titleLabel != null) _titleLabel.Text = title ?? "Panggilan masuk";
            if (_bodyLabel != null) _bodyLabel.Text = body ?? "";
        }
    }
}
