# CallMe Windows Shell (WebView2)

Cangkang desktop Windows untuk CallMe: **EXE memuat UI langsung dari GitHub Pages** sehingga pemeliharaan/perubahan fitur ke depan cukup dilakukan di repo web (`github-pages/` → deploy), tanpa membundel ulang isi aplikasi.

## Cara kerja
- `CallMe.exe` membuka WebView2 (Microsoft Edge runtime) ke: **https://riacaya.github.io/callme/**
- Profil/data WebView2: `%LOCALAPPDATA%\CallMe\WebView2`
- Log: `%LOCALAPPDATA%\CallMe\callme-shell.log`

## Fitur shell
- **System tray**: menutup jendela membuat app tetap berjalan di tray (untuk tetap menerima notifikasi/panggilan selama app & Windows aktif). Menu tray: Buka, Mulai saat Windows menyala, Keluar.
- **Startup Windows**: toggle dari menu tray (Registry `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`).
- **Single instance**: mencegah lebih dari satu instance.
- **Notifikasi native (bridge)**: ketika ada panggilan/pesan masuk, web app (dari GitHub Pages) mengirim sinyal ke shell via `chrome.webview`. Untuk **pesan** shell menampilkan notifikasi tray/balloon; untuk **panggilan masuk** shell menampilkan dialog **Terima/Tolak** (Terima membuka CallMe & menerima panggilan, Tolak menolak) — perilaku diselaraskan dengan APK. Klik notifikasi pesan untuk membuka CallMe. Ini membantu saat jendela disembunyikan ke tray.
- Izin mikrofon/kamera/notifikasi diizinkan untuk origin `https://riacaya.github.io/`.

## Batasan penting
- Shell ini **tidak membangunkan PC dari sleep**. Untuk menerima panggilan/notifikasi, Windows harus menyala dan CallMe berjalan (bisa di tray/startup).
- Keandalan panggilan/pesan masuk tetap bergantung koneksi P2P/push, status daya, dan dukungan WebView2/service worker. Notifikasi native dari shell muncul jika event masuk diterima oleh web app yang sedang berjalan di dalam shell.
- Jika memakai shell versi lama, rebuild `CallMe.exe` agar bridge notifikasi native aktif.

## Build
Prasyarat: Windows dengan .NET Framework `csc.exe` (bawaan) dan internet saat pertama kali mengunduh SDK WebView2 (jika belum ada).

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\shell\build-shell.ps1
```

Output di folder `windows-app`: `CallMe.exe`, `Microsoft.Web.WebView2.*.dll`, `runtimes\*\native\WebView2Loader.dll`, dan `assets\logo-192.png`.

## Prasyarat runtime
- **Microsoft Edge WebView2 Runtime** (umumnya sudah ada di Windows 10/11). Jika belum: https://developer.microsoft.com/microsoft-edge/webview2/
